<template>
  <div class="set">
    <tree :treeData="treeData"
    :treeSerial="1"
    :defaultExpanded="defaultExpanded"
    :defaultChecked="defaultChecked"
    ></tree>
  </div>
</template>

<script>
import tree from './tree'

export default {
  name: 'setTree',
  props: [
    'treeData',
    'triangle',
    'checkbox',
    'defaultExpanded',
    'defaultChecked'
  ],
  components: {
    tree
  },
  mounted () {
    // console.log(this.treeData)
    this.initialize(this.treeData, 1)
    this.check(this.treeData)
    this.treeData.push()
  },
  methods: {
    initialize (treeData, count) {
      treeData.map((item, index) => {
        item.layer = count
        item.triangle = this.triangle
        item.checkbox = this.checkbox
        if (this.defaultExpanded.indexOf(item.id) + 1 || this.defaultChecked.indexOf(item.id) + 1) {
          item.flag = true
        }
        if (item.list) {
          this.initialize(item.list, count + 1)
        }
      })
    },
    check (treeData) {
      for (let i = 0; i < treeData.length; i++) {
        if (treeData[i].flag) {
          if (treeData[i].list) {
            let c = this.check(treeData[i].list)
            if (c) {
              treeData[i].flag = true
              return true
            }
          }
          return true
        } else if (treeData[i].list) {
          let c = this.check(treeData[i].list)
          if (c) {
            treeData[i].flag = true
            return true
          }
        }
      }
    }
  }
}
</script>

<style>

</style>
