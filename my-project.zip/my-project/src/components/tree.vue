<template>
  <div class="tree">
    <div v-for="(item,index) in treeData" :key="index">
      <div class="box" :style="{'padding-left': item.layer*10+'px'}" @click.stop="doClick(index)">
        <span v-if="item.list&&item.triangle" :class="item.flag?'b':'c'" :style="{'left': item.layer*10-10+'px'}"></span>
        <div v-if="item.checkbox" class="checkBox" @click.stop="doSelect(index)">
          <div :class="item.check?'ba':''">{{item.check === 2?'-':'✓'}}</div>
        </div>
        <span>{{item.title}}</span>
      </div>
      <div v-if="item.list">
        <tree v-if="item.flag"
        :treeData="item.list"
        :treeSerial="index"
        @getSelect="setSelect"></tree>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'tree',
  props: [
    'treeData',
    'treeSerial',
    'defaultChecked'
  ],
  mounted () {
    if (this.defaultChecked && this.defaultChecked[0]) {
      this.doChecked(this.treeData, this.defaultChecked)
      // console.log(this.defaultChecked)
      // console.log(this.treeData)
    }
  },
  methods: {
    doClick (i) {
      this.treeData.map((item, index) => {
        if (index === i) {
          item.flag = !item.flag
          if (item.list) item.list.push()
        }
      })
      // console.log(this.treeData)
    },
    setSelect: function (serial, val) {
      let checkOne = true
      let checkTwo = true
      let checkThree = true
      this.treeData.map((item, index) => {
        if (index === serial) {
          item.check = val
        }
        item.check ? checkOne = false : checkTwo = false
        item.check === 2 ? checkThree = false : item.check = item.check
      })
      this.$emit('getSelect', this.treeSerial, 2)
      if (checkOne) this.$emit('getSelect', this.treeSerial, 0)
      if (checkTwo && checkThree) this.$emit('getSelect', this.treeSerial, 1)
      this.treeData.push()
    },
    doSelect: function (i) {
      let value
      let checkOne = true
      let checkTwo = false
      this.treeData[i].check === 1 ? value = 0 : value = 1
      this.treeData.map((item, index) => {
        if (index === i) {
          item.check = value
          this.doCount(item, value)
        }
        item.check ? checkOne = false : checkTwo = true
      })
      this.$emit('getSelect', this.treeSerial, 2)
      if (checkOne) this.$emit('getSelect', this.treeSerial, 0)
      if (!checkTwo) this.$emit('getSelect', this.treeSerial, 1)
      this.treeData.push()
    },
    doCount: function (item, value) {
      if (item.list) {
        item.list.map((item, index) => {
          item.check = value
          if (item.list) this.doCount(item, value)
        })
        item.list.push()
      }
    },
    doChecked: function (treeData, defaultChecked) {
      // console.log(defaultChecked)
      treeData.map((item, index) => {
        if (defaultChecked.indexOf(item.id) + 1) {
          let i = index
          // let id = item.id
          // setTimeout(() => {
          this.doSelect(i)
          // let val = defaultChecked.indexOf(id)
          // defaultChecked.splice(val, 1)
          if (item.list && defaultChecked[0]) {
            this.doChecked(item.list, defaultChecked)
          }
          // }, 1)
        } else if (item.list && defaultChecked[0]) {
          this.doChecked(item.list, defaultChecked)
        }
      })
    }
  }
}
</script>

<style>
</style>
